const alumnos = 
[
{"nombre":"Zoe","apellido":"Ramirez","ciudad":"Barcelona","fecha_nacimiento":"2005-08-19","sexo":"M"},
{"nombre":"David","apellido":"Schmidt","ciudad":"Barcelona","fecha_nacimiento":"2004-12-25","sexo":"H"},
{"nombre":"Cristina","apellido1":"Lemke","ciudad":"Barcelona","fecha_nacimiento":"2005-01-06","sexo":"M"},
{"nombre":"Esther","apellido1":"Spencer","ciudad":"Barcelona","fecha_nacimiento":"1956-12-19","sexo":"M"},
{"nombre":"Carmen","apellido1":"Streich","ciudad":"Hospitalet","fecha_nacimiento":"1958-10-15","sexo":"M"},
{"nombre":"Alfredo","apellido1":"Stiedemann","ciudad":"Barcelona","fecha_nacimiento":"1957-01-01","sexo":"H"},
{"nombre":"Manolo","apellido1":"Hamill","ciudad":"Barcelona","fecha_nacimiento":"2005-04-23","sexo":"H"},
{"nombre":"Alejandro","apellido1":"Kohler","ciudad":"Barcelona","fecha_nacimiento":"1980-03-14","sexo":"H"},
{"nombre":"Antonio","apellido1":"Fahey","ciudad":"Hospitalet","fecha_nacimiento":"1982-03-18","sexo":"H"},
{"nombre":"Guillermo","apellido1":"Ruecker","ciudad":"Barcelona","fecha_nacimiento":"1973-05-05","sexo":"H"},
{"nombre":"Micaela","apellido1":"Monahan","ciudad":"Barcelona","fecha_nacimiento":"1976-02-25","sexo":"H"},
{"nombre":"Francesca","apellido1":"Schowalter","ciudad":"Barcelona","fecha_nacimiento":"1980-10-31","sexo":"H"}
]

const precioBaseMatricula = 250;